# Hello World
A SIMPLE FILE TO DESCRIBE THE PROJECT PACKAGING IN PYTHON - and a program t simply say hello

## Installation 
Run the following to install:
```python
pip install helloNoushi
```

## Usage
```python
from helloNoushi import sayhello
``` 
# Generate "Hello Lovely World ...!!!"
sayhello()

# Generate "Hello Lovely guys ...!!!"
sayhello('guys')

# Developing Hello World

To install helloNoushi, along with the tools you need to develope and run tests, run the following in your virtualenv:
```bash
$ pip install -e .[dev]
``` 